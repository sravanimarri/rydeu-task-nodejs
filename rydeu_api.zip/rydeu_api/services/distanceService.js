
exports.getDistance = async (pickup, destination) => {
    try {
     
      const distanceData = {
        'Berlin Central': { 'Berlin Airport': 10, 'Berlin Zoo': 5 },
        'Paris': { 'Eiffel Tower': 3, 'Louvre Museum': 2 },
        'London': { 'London Bridge': 5, 'Big Ben': 2 },
      };
  
     
      const distance = distanceData[pickup]?.[destination];
  
      if (!distance) {
        throw new Error("Invalid pickup or destination.");
      }
  
      return distance; 
    } catch (error) {
      console.error("Error in getDistance:", error.message);
      throw error;
    }
  };
  