
const db = require('../config/db');

exports.calculatePrice = async (city, vehicleType, distance) => {
  try {
    const [rows] = await db.execute(
      `SELECT * FROM pricing WHERE city = ? AND vehicle_type = ? LIMIT 1`,
      [city, vehicleType]
    );

    if (rows.length === 0) {
      throw new Error(`Pricing not found for city: ${city}, vehicle: ${vehicleType}`);
    }

    const pricing = rows[0];
    const { base_km, base_amount, amount_per_km, airport_fees } = pricing;

    let totalPrice = 0;

    
    if (isNaN(distance)) {
      throw new Error("Invalid distance value.");
    }

    if (distance <= base_km) {
      totalPrice = base_amount + airport_fees;
    } else {
      const extraKm = distance - base_km;
      totalPrice = base_amount + (extraKm * amount_per_km) + airport_fees;
    }

    totalPrice = parseFloat(totalPrice);
    return parseFloat(totalPrice.toFixed(2)); 
  } catch (error) {
    console.error("Error in calculatePrice:", error.message);
    throw error;
  }
};



exports.getCityFlag = async (city) => {
    try {
      const [rows] = await db.execute(
        `SELECT city_flag FROM pricing WHERE city = ? LIMIT 1`,
        [city]
      );
  
      if (rows.length === 0) {
        throw new Error(`City flag not found for city: ${city}`);
      }
  
      return rows[0].city_flag; 
    } catch (error) {
      console.error("Error in getCityFlag:", error.message);
      throw error;
    }
  };
  