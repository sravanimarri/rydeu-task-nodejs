const distanceService = require('../services/distanceService');
const pricingService = require('../services/pricingService');

exports.checkEmailRequirement = async (req, res) => {
  try {
    const { pickup, destination, city, vehicle_type } = req.body;

    if (!pickup || !destination || !city || !vehicle_type) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    
    const distance = await distanceService.getDistance(pickup, destination);
    
    
    const price = await pricingService.calculatePrice(city, vehicle_type, distance);

   
    const cityFlag = await pricingService.getCityFlag(city);
    
   
    const emailRequired = distance > 30 || cityFlag || price < 50;

    return res.status(200).json({ result: emailRequired, estimated_price: price });
  } catch (error) {
    console.error("Error:", error.message);
    res.status(500).json({ error: error.message });
  }
};
