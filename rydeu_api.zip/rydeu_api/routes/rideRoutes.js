const express = require('express');
const { body, validationResult } = require('express-validator');
const router = express.Router();
const rideController = require('../controllers/rideController');

router.post(
  '/check',
  [
    body('pickup').notEmpty().withMessage('Pickup address is required'),
    body('destination').notEmpty().withMessage('Destination address is required'),
    body('city').notEmpty().withMessage('City is required'),
  ],
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }
    next();
  },
  rideController.checkEmailRequirement
);

module.exports = router;
